package com.edu.secondbatch;

enum ShapeColor {
	Blue,
	Yellow,
	Red,
	Green,
	White;
	}
