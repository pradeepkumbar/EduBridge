package com.edu.secondbatch;

public interface Resizable {
	void resize(double percentage);
}
