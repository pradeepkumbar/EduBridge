package com.edu.secondbatch;

public interface Shape {

	double area();
}
