package com.edu.secondbatch;

public interface Recolorable {
	 void recolor(ShapeColor sc);
	

}
