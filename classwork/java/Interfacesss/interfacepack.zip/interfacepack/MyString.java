package interfacepack;

public class MyString extends  {

}
