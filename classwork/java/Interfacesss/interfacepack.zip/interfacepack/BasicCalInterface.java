package interfacepack;

public interface BasicCalInterface{
	
	void add();
	void sub();
	void mult();
	void div();

}
