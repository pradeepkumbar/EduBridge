package interfacepack;

public interface AdvanceCal {

	void log();
	double getPi();
	void sin();
	void square(int x);
}
