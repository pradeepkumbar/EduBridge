package interfacepack;

public interface ElectronicGadgets {
	
	int count=0;//public static final
	void on();//public abstract
	public abstract void off();

}
