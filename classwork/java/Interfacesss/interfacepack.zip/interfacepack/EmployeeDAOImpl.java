package interfacepack;

import java.io.Serializable;

public class EmployeeDAOImpl implements EmployeeDAO, Serializable {

	@Override
	public void save(Employee emp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Employee[] findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee update(Employee emp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Employee emp) {
		// TODO Auto-generated method stub
		
	}

}
